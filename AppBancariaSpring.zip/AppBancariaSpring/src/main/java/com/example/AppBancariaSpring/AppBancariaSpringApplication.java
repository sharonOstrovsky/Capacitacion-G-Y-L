package com.example.AppBancariaSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppBancariaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppBancariaSpringApplication.class, args);
	}

}
