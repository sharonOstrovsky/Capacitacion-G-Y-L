package com.example.AppBancariaSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppBancariaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
