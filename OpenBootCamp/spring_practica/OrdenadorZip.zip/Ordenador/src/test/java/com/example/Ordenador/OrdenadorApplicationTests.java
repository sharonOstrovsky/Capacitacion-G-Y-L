package com.example.Ordenador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdenadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
