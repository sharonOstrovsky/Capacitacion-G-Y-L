package com.example.appbancariaspring.Entity;

import jakarta.persistence.*;

@Entity
@Table(name="Tarjeta")
public class Tarjeta {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String numero;

    public Tarjeta() {
    }

    //public Tarjeta(String numero) {
    //    this.numero = numero;
    //}

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    @Override
    public String toString() {
        return "Tarjeta{" +
                "numero='" + numero + '\'' +
                '}';
    }
}

