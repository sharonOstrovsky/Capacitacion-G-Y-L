package com.example.appbancariaspring.Entity;

import jakarta.persistence.*;

import java.util.ArrayList;


@Entity
@Table(name="Banco")
public class Banco {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @OneToMany
    private ArrayList<CuentaBancaria> cuentas;

    public Banco() {
    }

    public Banco(ArrayList<CuentaBancaria> cuentas) {
        this.cuentas = cuentas;
    }

    public ArrayList<CuentaBancaria> getCuentas() {
        return cuentas;
    }

    public void setCuentas(ArrayList<CuentaBancaria> cuentas) {
        this.cuentas = cuentas;
    }

    @Override
    public String toString() {
        return "Banco{" +
                "cuentas=" + cuentas +
                '}';
    }
}
