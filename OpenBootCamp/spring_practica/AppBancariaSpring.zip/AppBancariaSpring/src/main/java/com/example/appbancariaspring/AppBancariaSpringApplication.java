package com.example.appbancariaspring;

import com.example.appbancariaspring.Entity.Banco;
import com.example.appbancariaspring.Entity.Cliente;
import com.example.appbancariaspring.Entity.CuentaBancaria;
import com.example.appbancariaspring.Repository.BancoRepository;
import com.example.appbancariaspring.Repository.ClienteRepository;
import com.example.appbancariaspring.Repository.CuentaBancariaRepository;
import com.example.appbancariaspring.Service.BancoService;
import com.example.appbancariaspring.Service.ClienteService;
import com.example.appbancariaspring.Service.CuentaBancariaService;
import com.example.appbancariaspring.Service.TarjetaService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class AppBancariaSpringApplication {


    public static void main(String[] args) {

        ApplicationContext context = SpringApplication.run(AppBancariaSpringApplication.class, args);
        //BancoService bancoService = (BancoService) context.getBean("bancoService");
/*
       ClienteRepository repository = context.getBean(ClienteRepository.class);
        CuentaBancariaRepository repositorycuenta = context.getBean(CuentaBancariaRepository.class);
       Cliente cliente = new Cliente("sharon", "ostrovsky", 39915620, 26, "sharon@gmail.com", "calle 1234", "Argentina");

       repository.save(cliente);
        System.out.println("Encontrar");
        System.out.println("Total de clientes es : "+ repository.count());
        System.out.println("------------------");
        System.out.println(repository.findAll());

        CuentaBancaria cuenta1 = new CuentaBancaria("sharon", "sharon", cliente, null, 100000);
        repositorycuenta.save(cuenta1);
        System.out.println(repositorycuenta.findAll());
*/
        BancoService bancoService = new BancoService();
        bancoService.inicializarRepositorios(context);
        Banco bancoPreArmado = bancoService.crearBancoPreArmado();

        //System.out.println("Encontrar");
        //System.out.println("Total de bancos es : "+ bancoRepository.count());
        //System.out.println("------------------");
       // bancoService.menu(bancoPreArmado);
        //BancoService servicoBanco = new BancoService();


        //bancoService.crearBanco();
    }

}

